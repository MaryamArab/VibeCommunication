package odu.vibe_communication;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Receiver extends AppCompatActivity implements SensorEventListener, View.OnClickListener  {

    Button btnReceive;
    Button btnStop;
    TextView tvMessage;
    TextView tvAccX;
    TextView tvAccY;
    TextView tvAccZ;

    float ALPHA = 0.25f;



    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private float[] gravSensorVals;


    String path;
    PrintWriter file=null ;
    File settingFile;



    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receiver);

        btnReceive= (Button)findViewById(R.id.btnReceive);
        btnReceive.setOnClickListener(this);

        btnStop =(Button)findViewById(R.id.btnStop);
        btnStop.setOnClickListener(this);

        tvMessage = (TextView)findViewById(R.id.tvMessage);
        tvAccX = (TextView)findViewById(R.id.tvAccX);
        tvAccY = (TextView)findViewById(R.id.tvAccY);
        tvAccZ = (TextView)findViewById(R.id.tvAccZ);

        String fSaveName = Environment.getExternalStorageDirectory().toString();
        File folder = new File(fSaveName,"AccData");
        folder.mkdir();
        // Create the file
        path = Environment.getExternalStorageDirectory().getPath();
        settingFile = new File(path+"/AccData/MyFile_asdf.csv");
        try {
            file  = new PrintWriter( new FileWriter( settingFile, false ) );
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_receiver, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
       int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId())
        {
            case R.id.btnReceive:
                ActivateSensor();
                break;
            case R.id.btnStop: {
                mSensorManager.unregisterListener(this, mAccelerometer);
                file.close();
                break;
            }
            default:
                break;
        }
    }

        private void ActivateSensor() {
            mSensorManager = (SensorManager) getSystemService(this.SENSOR_SERVICE);
            mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }


    @Override
    public void onSensorChanged(SensorEvent event) {
        String line = String.valueOf(event.timestamp)
                    + "," + event.values[0]
                    + "," + event.values[1]
                    + "," + event.values[2] + "\n";
        file.append(line);

        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
        {
            gravSensorVals = lowPass(event.values.clone(), gravSensorVals);
        }
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            if(event.values[0] > gravSensorVals[0])
                tvAccX.setText("Accel X: " + event.values[0]  + "grav 0 :"+ gravSensorVals[0]);
            if(event.values[1] > gravSensorVals[1])
                tvAccY.setText("Accel Y: " + event.values[1]);
            if(event.values[2] > gravSensorVals[2])
                tvAccZ.setText("Accel Z: " + event.values[2]);
        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    protected float[] lowPass( float[] input, float[] output ) {
        if ( output == null ) return input;
        for ( int i=0; i<input.length; i++ ) {
            output[i] = output[i] + ALPHA * (input[i] - output[i]);
        }
        return output;
    }
}
